package com.winsky.lease.common.util;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * WEB应用上下文
 */
public class ServletContextUtils implements ServletContextListener {

    private static ServletContext servletContext;

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        if (Helper.isNull(servletContext)) {
            setServletContext(servletContextEvent.getServletContext());
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        setServletContext(null);
    }

    public static ServletContext getServletContext() {
        return servletContext;
    }

    public static String getRootPath() {
        if (Helper.isNull(servletContext)) {
            return null;
        }
        String rs = servletContext.getRealPath("/");
        if (rs.substring(rs.length() - 1) == "/") {
            return rs;
        }
        return rs + "/";
    }

    public static String getClassPath() {
        if (Helper.isNull(servletContext)) {
            return ServletContext.class.getResource("/").getPath();
        }
        return getRootPath() + "WEB-INF/classes/";
    }

    public static void setServletContext(ServletContext servletContext) {
        ServletContextUtils.servletContext = servletContext;
    }
}

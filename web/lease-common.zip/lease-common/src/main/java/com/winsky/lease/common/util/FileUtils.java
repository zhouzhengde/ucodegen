/*
 * Copyright (c) 2015. Bond(China)
 */
package com.winsky.lease.common.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;

/**
 * 文件操作工具
 *
 * @author Bond(China)
 */
public final class FileUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtils.class);

    private static final String LOG_TAG = "FileUtils Read";

    private FileUtils() {
    }

    /**
     * 复制文件到指定目录，如果src为路径，则只复制其名下的所有子目录和子文件
     *
     * @param src  可为路径，也可是文件
     * @param dest 必需为路径
     */
    public static void copy(File src, File dest) {
        if (dest.isFile()) {
            return;
        }
        if (src.isDirectory()) {
            copyFolder(src, dest);
            return;
        }
        File realFile = new File(dest.getAbsoluteFile() + "/" + src.getName());
        if (!realFile.exists()) {
            try {
                realFile.createNewFile();
            } catch (IOException e) {
                LOGGER.error("[Create file error]", e);
            }
        }
        copyFile(src, realFile);
    }

    private static void copyFile(File src, File realFile) {

        try (FileInputStream fi = new FileInputStream(src);
             FileOutputStream fo = new FileOutputStream(realFile);
             FileChannel in = fi.getChannel();
             FileChannel out = fo.getChannel()) {

            in.transferTo(0, in.size(), out);
        } catch (IOException e) {
            LOGGER.error("[Transfer Channel error]", e);
        }
    }

    private static void copyFolder(File src, File dest) {
        File[] files = src.listFiles();
        for (File subFile : files) {
            File subDest = dest;
            if (subFile.isDirectory()) {
                subDest = new File(dest.getAbsolutePath() + "/" + subFile.getName());
            }
            if (!subDest.exists()) {
                subDest.mkdir();
            }
            copy(subFile, subDest);
        }
    }

    /**
     * 删除单个文件
     *
     * @param sPath 被删除文件的文件名
     * @return 单个文件删除成功返回true，否则返回false
     */
    public static boolean deleteFile(String sPath) {
        File file = new File(sPath);
        if (file.isFile() && file.exists()) {
            file.delete();
            return true;
        }
        return false;
    }

    /**
     * 读取文件流
     *
     * @param file 需要读取的文件
     * @return String
     */
    public static String read(File file) {
        StringBuilder sb = new StringBuilder();
        try (InputStream inputStream = new FileInputStream(file)) {
            return read(inputStream);
        } catch (Exception e) {
            LOGGER.error(LOG_TAG, e);
        }
        return sb.toString();
    }

    /**
     * 读取文件
     *
     * @param inputStream 需要读取的文件
     * @return String
     */
    public static String read(InputStream inputStream) {
        try {
            return new String(getBytes(inputStream));
        } catch (IOException e) {
            LOGGER.warn(LOG_TAG, e);
            return StringUtils.EMPTY;
        }
    }

    /**
     * 读取文件
     *
     * @param inputStream
     * @param charset
     * @return
     */
    public static String read(InputStream inputStream, String charset) {
        try {
            return new String(getBytes(inputStream), charset);
        } catch (IOException e) {
            LOGGER.warn(LOG_TAG, e);
            return StringUtils.EMPTY;
        }
    }

    /**
     * 读取文件
     *
     * @param inputStream
     * @param charset
     * @return
     */
    public static String read(InputStream inputStream, Charset charset) {
        try {
            return new String(getBytes(inputStream), charset);
        } catch (IOException e) {
            LOGGER.warn(LOG_TAG, e);
            return StringUtils.EMPTY;
        }
    }

    /**
     * 关闭文件流
     *
     * @param in InputStream
     */
    public static void close(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException e) {
                LOGGER.error("[Close file steam error]", e);
            }
        }
    }

    /**
     * 关闭文件流
     *
     * @param out 输出流
     */
    public static void close(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException e) {
                LOGGER.error("[Close file steam error]", e);
            }
        }
    }

    /**
     * 关闭文件流
     *
     * @param in
     */
    public static void close(Reader in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException e) {
                LOGGER.error("[Close file steam error]", e);
            }
        }
    }

    /**
     * 关闭文件流
     *
     * @param out
     */
    public static void close(Writer out) {
        if (out != null) {
            try {
                out.flush();
                out.close();
            } catch (IOException e) {
                LOGGER.error("[Close file steam error]", e);
            }
        }
    }

    /**
     * 关闭文件流
     *
     * @param channel FileChannel
     */
    public static void close(FileChannel channel) {
        if (channel != null) {
            try {
                channel.close();
            } catch (IOException e) {
                LOGGER.error("[Close file steam error]", e);
            }
        }
    }

    /**
     * 获取文件名的后缀
     *
     * @param fileName
     * @return
     */
    public static String getFileExt(String fileName) {
        if (!fileName.contains(".")) {
            throw new IllegalStateException("The format of fileName is illegal.");
        }
        return fileName.substring(fileName.lastIndexOf(".") + 1);
    }

    /**
     * @param file
     * @return
     * @throws IOException
     */
    public static byte[] getBytes(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return getBytes(fis);
        }
    }

    /**
     * 获取缓冲流
     *
     * @param fis
     * @return
     * @throws IOException
     */
    public static byte[] getBytes(InputStream fis) throws IOException {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream(1024 * 512)) {
            byte[] bts = new byte[1024 * 512];
            int len = fis.read(bts);
            while (len != -1) {
                bos.write(bts, 0, len);
                len = fis.read(bts);
            }
            return bos.toByteArray();
        } finally {
            close(fis);
        }
    }
}

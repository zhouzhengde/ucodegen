package com.winsky.lease.common.servlet;


import com.winsky.lease.common.util.Constants;
import com.winsky.lease.common.util.FileUtils;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 * Created by Bond(China) on 2017/5/25.
 */
public class BasicServletRequestWrapper extends HttpServletRequestWrapper {

    private byte[] body;

    public BasicServletRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        body = FileUtils.read(request.getInputStream(), Charset.forName(Constants.ENCODING)).getBytes(Charset.forName(Constants.ENCODING));
    }

    public void writeBody(String requestBody) throws IOException {
        body = requestBody.getBytes(Charset.forName(Constants.ENCODING));
    }

    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream()));
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {

        final ByteArrayInputStream bais = new ByteArrayInputStream(body);

        return new ServletInputStream() {

            @Override
            public int read() throws IOException {
                return bais.read();
            }

            @Override
            public boolean isFinished() {
                return false;
            }

            @Override
            public boolean isReady() {
                return false;
            }

            /**
             * Need't to set read listener
             * @param readListener
             */
            @Override
            public void setReadListener(ReadListener readListener) {
                // Need't to set read listener
            }
        };
    }
}

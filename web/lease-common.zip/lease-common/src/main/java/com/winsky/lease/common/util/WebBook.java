/*
 * Copyright (c) 2015. Bond(China)
 */
package com.winsky.lease.common.util;

import net.sf.jxls.transformer.XLSTransformer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.Map;

/**
 * To Export data to a format file
 *
 * @author Bond(China)
 * @version 1.0.0
 */
public final class WebBook {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebBook.class);

    private String fileName;

    private String contentType;

    /**
     * File type set
     */
    public enum FileType {

        XLS, XLS_X;

        public Workbook createWorkbook() {
            Workbook workbook = null;
            switch (this) {
                case XLS:
                    workbook = new HSSFWorkbook();
                    break;
                case XLS_X:
                    workbook = new XSSFWorkbook();
                    break;
                default:
                    workbook = new HSSFWorkbook();
            }
            return workbook;
        }

        public Workbook createWorkbook(InputStream inputStream) {
            Workbook workbook = null;
            try {
                switch (this) {
                    case XLS:
                        workbook = new HSSFWorkbook(inputStream);
                        break;
                    case XLS_X:
                        workbook = new XSSFWorkbook(inputStream);
                        break;
                    default:
                        workbook = new HSSFWorkbook(inputStream);
                }
            } catch (IOException e) {
                LOGGER.error("Initial WebBook Error", e);
            }
            return workbook;
        }
    }

    /**
     * Customize to template
     */
    @FunctionalInterface
    public interface CustomizeWorkbook {

        /**
         * Orient extend with outside
         *
         * @param workbook 文档
         * @return 文档
         */
        Workbook customize(Workbook workbook);
    }

    /**
     * To Export
     *
     * @param templateFile 模板文件
     * @param dataSource   数据源
     * @param response     响应HttpServletResponse
     */
    public void export(File templateFile, Map<String, Object> dataSource, HttpServletResponse response) {

        if (templateFile != null && !templateFile.exists()) {
            return;
        }

        try (InputStream in = new BufferedInputStream(new FileInputStream(templateFile)); OutputStream out = response.getOutputStream()) {
            response.reset();
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            response.setContentType(getContentType());
            XLSTransformer transformer = new XLSTransformer();
            Workbook workbook = transformer.transformXLS(in, dataSource);
            workbook.write(out);
            out.flush();
        } catch (InvalidFormatException | IOException e) {
            LOGGER.error("[WebBook export]: Occur an error", e);
        }
    }

    /**
     * To Export
     *
     * @param fileType          文件类型
     * @param customizeWorkbook 客户化模板实例
     * @param response          响应HttpServletResponse
     */
    public void export(FileType fileType, CustomizeWorkbook customizeWorkbook, HttpServletResponse response) {

        try (OutputStream out = response.getOutputStream()) {

            response.reset();
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            response.setContentType(getContentType());
            Workbook workbook = fileType.createWorkbook();
            customizeWorkbook.customize(workbook).write(out);
        } catch (IOException e) {
            LOGGER.error("[WebBook export]: Occur an error", e);
        }
    }

    /**
     * Set FileName
     *
     * @param fileName 文件名
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Set Content Type
     *
     * @param contentType ContentType
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentType() {
        if (Helper.isEmpty(contentType)) {
            return "application/octet-stream";
        }
        return contentType;
    }
}
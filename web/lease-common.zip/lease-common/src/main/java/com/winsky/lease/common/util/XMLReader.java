package com.winsky.lease.common.util;

import com.jayway.jsonpath.JsonPath;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 读取XML文件
 * Created by Bond(China) on 2017/4/27.
 */
public class XMLReader {

    private static final Logger LOGGER = LoggerFactory.getLogger(XMLReader.class);

    private String xml;

    private JSONObject jsonObject;

    public XMLReader(String xml) {
        this.xml = xml;
        jsonObject = (JSONObject) new XMLSerializer().read(xml);
    }

    public Object get(String path) {
        try {
            return JsonPath.read(jsonObject, "$." + path);
        } catch (Exception e) {
            LOGGER.error("XML Reader parse error", e);
            return StringUtils.EMPTY;
        }
    }
}

package com.winsky.lease.common.util.httpclient;

import com.winsky.lease.common.util.Helper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Created by Bond(China)
 */
public final class ParameterUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ParameterUtils.class);

    private ParameterUtils() {
    }

    /**
     * 将一个对象序列成URL参数, 结果形如：?usrName=abc&pasword=sss
     *
     * @param clz
     * @param t
     * @param ignoreNull 是否忽略NUlL
     * @param <T>
     * @return
     */
    public static <T> String serialize(Class<T> clz, T t, boolean ignoreNull) {
        String result = "?";
        if (Helper.isNull(t)) {
            return result;
        }
        Field[] fields = clz.getDeclaredFields();
        Arrays.sort(fields, (o1, o2) -> o1.getName().compareToIgnoreCase(o2.getName()));
        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            String value = getString(t, field, ignoreNull);
            result += value;
            if (!Helper.isEmpty(value) && i < (fields.length - 1)) {
                result += "&";
            }
        }
        return result;
    }

    private static <T> String getString(T t, Field field, boolean ignoreNull) {
        String result = "";
        field.setAccessible(true);
        try {
            Object value = field.get(t);
            if (!Helper.isNull(value)) {
                result += field.getName() + "=" + value;
            }
            if (!ignoreNull && Helper.isNull(value)) {
                result += field.getName() + "=" + value;
            }
        } catch (IllegalAccessException e) {
            LOGGER.error("[Parameter Serialize]", e);
        } finally {
            field.setAccessible(false);
        }
        return result;
    }
}

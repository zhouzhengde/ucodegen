package com.winsky.lease.common.util;

/**
 * 错误code信息
 *
 * @author Bond(China)
 * @version 1.0.0
 */
public enum ExceptionCode {

    RESOURCE_NOT_EXIT("404", "访问的资源不存在！"),
    SYSTEM_ERROR("0000000", "系统错误，请联系系统管理员!"),
    ILLEGAL_PARAMETER("1000000", "非法参数错误!"),
    ILLEGAL_ACCESS("1000001", "非法访问/没有权限!"),
    FREQUENCY_ERROR("1000002", "请勿重复操作!"),
    UNKNOW_ERROR("1000003", "其它未知错误!"),

    WEBSERVICE_ERROR("1000004", "系统调用外部WEB服务调用错误!"),
    ILLEGAL_VALID_CODE("1000005", "验证码错误!"),
    PASSWORD_ERROR("1000006", "用户名或密码错误!"),
    UN_AUTHORIZED_ERROR("1000007", "请重新登入!"),
    ILLEGAL_CONTENT_TYPE("1000008", "不是可识别的请求参数类型，请仔细阅读接口文档或联系开发人员！"),

    REQUIRED_NOT_NULL("1000009", "必填参数不能空，请仔细核对接口要求！"),
    NOT_VALID_RESULT("1000010", "没有有效的结果需要处理！"),
    DISABLED_USER("1000011", "用户帐号已禁用！"),
    DATA_NOT_EXIST("1000012", "该数据已经过期或已经删除！"),
    API_INVALID("1000013", "该接口已经过期，暂不支持该服务！"),
    INVALID_OPT("1000014", "无效操作！"),
    INVALID_TOKEN("1000015", "无效TOKEN！"),
    INVALID_NONCE("1000016", "无效Nonce!"),
    ILLEGAL_SIGNATURE("1000017", "无效的签名！"),
    ILLEGAL_REQUEST_HEADER("1000018", "非法请求头，请指定signature!");

    private String code;

    private String message;

    private ExceptionCode(String value, String message) {
        this.code = value;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}

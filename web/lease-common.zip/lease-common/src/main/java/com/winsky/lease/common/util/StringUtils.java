package com.winsky.lease.common.util;

/**
 * 字符串操作工具
 * Created by Bond(China) on 2017/2/23.
 */
public final class StringUtils {
    private StringUtils() {
    }

    /**
     * 转换成模糊条件String
     *
     * @param src
     * @param left
     * @param right
     * @return
     */
    public static String toLike(String src, boolean left, boolean right) {
        String tSrc = src;
        if (Helper.isEmpty(tSrc)) {
            return src;
        }
        if (right) {
            tSrc = tSrc + "%";
        }
        if (left) {
            tSrc = "%" + tSrc;
        }
        return tSrc;
    }

    /**
     * 转换成模糊条件String
     *
     * @param src
     * @return "%" + src
     */
    public static String toLeftLike(String src) {
        return toLike(src, true, false);
    }

    /**
     * 转换成模糊条件String
     *
     * @param src
     * @return src + "%"
     */
    public static String toRightLike(String src) {
        return toLike(src, false, true);
    }

    /**
     * 转换成模糊条件String
     *
     * @param src
     * @return "%" + src + "%"
     */
    public static String toBothLike(String src) {
        return toLike(src, true, true);
    }

    /**
     * 修改URL中含有类似[key]的字符串为指定Value
     *
     * @param url
     * @param key
     * @param value
     * @return
     */
    public static String joinParam(String url, String key, String value) {
        if (Helper.isEmpty(url) || Helper.isEmpty(key)) {
            return url;
        }
        if (Helper.isNull(value)) {
            return url.replace("[" + key + "]", "");
        }
        return url.replace("[" + key + "]", value);
    }

    /**
     * 转换String的值为默认值
     *
     * @param value
     * @param defaultValue
     * @return
     */
    public static String value(String value, String defaultValue) {
        if (Helper.isEmpty(value)) {
            return defaultValue;
        }
        return value;
    }

}

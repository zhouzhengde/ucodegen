package com.winsky.lease.common.base;

import com.winsky.lease.common.entity.BaseEntity;

import java.io.Serializable;
import java.util.List;

/**
 * @author zhouzhengde(CN)
 * @date 2017/11/9.
 */
public class User extends BaseEntity {

    private Integer id;

    private String password;

    private String userName;

    private String gender;

    private List<Permission> permissionList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<Permission> getPermissionList() {
        return permissionList;
    }

    public void setPermissionList(List<Permission> permissionList) {
        this.permissionList = permissionList;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

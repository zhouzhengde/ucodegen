package com.winsky.lease.common.base;

import com.winsky.lease.common.entity.BaseEntity;
import com.winsky.lease.common.json.annotation.JsonPathValue;

import java.io.Serializable;
import java.util.List;

/**
 * @author zhouzhengde(CN)
 * @date 2017/11/9.
 */
public class UserVO extends BaseEntity {

    @JsonPathValue(path = "id")
    private Integer id;

    @JsonPathValue(path = "userName")
    private String name;

    @JsonPathValue(path = "permissionList")
    private List<Permission> permissionList;
}

package com.winsky.lease.common.base;

import com.winsky.lease.common.entity.BaseEntity;
import com.winsky.lease.common.json.annotation.JsonPathValue;

import java.io.Serializable;

/**
 * @author zhouzhengde(CN)
 * @date 2017/11/9.
 */
public class Permission implements Serializable {

    private String name;

    @JsonPathValue(path = "code")
    private String code;

    @JsonPathValue(path = "enable")
    private boolean enable;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

}

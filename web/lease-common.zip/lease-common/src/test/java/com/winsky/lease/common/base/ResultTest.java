package com.winsky.lease.common.base;

import com.winsky.lease.common.entity.Pager;
import com.winsky.lease.common.json.annotation.JsonPathValue;
import org.apache.commons.collections.map.HashedMap;
import org.junit.Before;
import org.junit.Test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * @author zhouzhengde(CN)
 * @date 2017/11/9.
 */
public class ResultTest {

    Map<String, Object> map;

    @Before
    public void init() {

        User user = new User();
        user.setGender("M");
        user.setId(1);
        user.setUserName("bond");
        user.setPassword("1234");
        Permission p = new Permission();
        p.setCode("100");
        p.setName("User ADD");
        p.setEnable(true);

        List<Permission> list = new ArrayList<>();
        list.add(p);
        user.setPermissionList(list);
        Pager<User> pager = new Pager<>();
        List<User> userList = new ArrayList<>();
        userList.add(user);
        pager.setRows(userList);

//        pager.setCondition(user);

        ResultMap.put(pager);

        map = ResultMap.success();

    }

    @Test
    public void newInstance() throws Exception {
        Result rs = Result.newInstance(map, UserVO.class);
        assertNotNull(rs.getResult());
    }
}



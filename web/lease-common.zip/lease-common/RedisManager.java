package com.moi.mypt.redis;

import org.apache.commons.lang.StringUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.PostConstruct;
import java.util.Set;

public class RedisManager {

    private String url = null;

    private int port = 6379;

    private int timeout = 0;

    private String password = null;

    private JedisPool jedisPool = null;

    private int maxActive = 1000;

    private int maxIdle = 20;

    private int maxWaitMillis = 1000;

    public RedisManager() {
    }

    @PostConstruct
    public void init() {
        url = StringUtils.defaultIfBlank(url, "127.0.0.1");
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(maxActive);
        config.setMaxIdle(maxIdle);
        config.setMaxWaitMillis(maxWaitMillis);
        config.setTestOnBorrow(false);
        if (StringUtils.isNotBlank(password)) {
            jedisPool = new JedisPool(new JedisPoolConfig(), url, port, timeout, password);
        } else if (timeout != 0) {
            jedisPool = new JedisPool(new JedisPoolConfig(), url, port, timeout);
        } else {
            jedisPool = new JedisPool(new JedisPoolConfig(), url, port);
        }
    }

    public Jedis getJedis() {
        return jedisPool.getResource();
    }

    public String get(String key) {
        try (Jedis jedis = jedisPool.getResource();) {
            return jedis.get(key);
        }
    }

    public void set(byte[] key, byte[] value, int timeToLiveSeconds) {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.setex(key, timeToLiveSeconds, value);
        }
    }

    public void set(byte[] key, byte[] value) {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.set(key, value);
        }
    }

    public byte[] get(byte[] key) {
        try (Jedis jedis = jedisPool.getResource();) {
            return jedis.get(key);
        }
    }

    public void set(String key, String value) {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.set(key, value);
        }
    }

    public void set(String key, String value, int timeToLiveSeconds) {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.setex(key, timeToLiveSeconds, value);
        }
    }

    public void del(String key) {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.del(key);
        }
    }

    public void flushDB() {
        try (Jedis jedis = jedisPool.getResource();) {
            jedis.flushDB();
        }
    }

    public long dbSize() {
        try (Jedis jedis = jedisPool.getResource();) {
            return jedis.dbSize();
        }
    }

    public Set<String> keys(String pattern) {
        try (Jedis jedis = jedisPool.getResource();) {
            return jedis.keys(pattern);
        }
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setMaxActive(int maxActive) {
        this.maxActive = maxActive;
    }

    public void setMaxIdle(int maxIdle) {
        this.maxIdle = maxIdle;
    }

    public void setMaxWaitMillis(int maxWaitMillis) {
        this.maxWaitMillis = maxWaitMillis;
    }
}
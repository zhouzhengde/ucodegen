package com.moi.mypt.shiro.filter;

import com.moi.mypt.common.base.ResultMap;
import com.moi.mypt.common.exception.ServiceException;
import com.moi.mypt.common.util.$;
import com.moi.mypt.common.util.AESCoder;
import com.moi.mypt.common.util.ExceptionCode;
import com.moi.mypt.common.util.SHA1;
import com.moi.mypt.redis.RedisManager;
import com.moi.mypt.redis.SerializationUtils;
import net.sf.json.JSONObject;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ThreadContext;
import org.apache.shiro.web.subject.support.WebDelegatingSubject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Bond(China) on 2017/7/18.
 */
public class OAuth2Filter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(OAuth2Filter.class);

    private String secretKey;

    private RedisManager redisManager;

    public void setRedisManager(RedisManager redisManager) {
        this.redisManager = redisManager;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        response.setContentType("application/json;charset=UTF-8");

        String token = request.getHeader("token");
        if ($.isNull(token)) {
            // 兼容Session方式
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // Check signature
        String nonce = request.getHeader("nonce");
        String signature = request.getHeader("signature");
        String timestamp = request.getHeader("timestamp");
        if ($.isEmpty(nonce) || $.isEmpty(signature) || $.isEmpty(timestamp)) {
            handleError(response, new ServiceException(ExceptionCode.ILLEGAL_REQUEST_HEADER));
            return;
        }
        if (nonce.length() > 64) {
            handleError(response, new ServiceException(ExceptionCode.INVALID_NONCE));
            return;
        }
        String encrypt = SHA1.encrypt(new String[]{secretKey, nonce, timestamp});
        if (!$.isEqual(signature, encrypt)) {
            handleError(response, new ServiceException(ExceptionCode.ILLEGAL_SIGNATURE));
            return;
        }

        // Decrypt token to get real token
        try {
            token = getToken(request);
        } catch (ServiceException e) {
            handleError(response, e);
            return;
        }

        LOGGER.info("获取Session:" + token);
        // 从Redis中获取Session
        Session session = getSession(token);
        if ($.isNull(session)) {
            response.getWriter().write(JSONObject.fromObject(ResultMap.failure(new ServiceException(ExceptionCode.UN_AUTHORIZED_ERROR))).toString());
            response.getWriter().flush();
            response.getWriter().close();
            return;
        }

        // Bind session with request
        bindSubject(servletRequest, servletResponse, session);
        filterChain.doFilter(servletRequest, servletResponse);
    }

    private void bindSubject(ServletRequest servletRequest, ServletResponse servletResponse, Session session) {
        PrincipalCollection principals = (PrincipalCollection) session.getAttribute("org.apache.shiro.subject.support.DefaultSubjectContext_PRINCIPALS_SESSION_KEY");
        WebDelegatingSubject subject = (WebDelegatingSubject) SecurityUtils.getSubject();
        WebDelegatingSubject delegatingSubject = new WebDelegatingSubject(
                principals,
                true,
                session.getHost(),
                session,
                servletRequest,
                servletResponse,
                subject.getSecurityManager());
        ThreadContext.unbindSubject();
        ThreadContext.bind(delegatingSubject);
    }

    private Session getSession(String token) throws IOException {
        String sessionStr = redisManager.get(token);
        if ($.isNull(sessionStr)) {
            return null;
        }
        return SerializationUtils.deserialize(sessionStr);
    }

    private String getToken(HttpServletRequest request) throws ServiceException {
        String token = request.getHeader("token");
        try {
            return AESCoder.decryptToString(token.getBytes(), secretKey.getBytes());
        } catch (Exception e) {
            throw new ServiceException(ExceptionCode.INVALID_TOKEN);
        }
    }

    @Override
    public void destroy() {

    }

    private void handleError(HttpServletResponse response, ServiceException e) throws IOException {
        response.getWriter().write(JSONObject.fromObject(ResultMap.failure(e)).toString());
        response.getWriter().flush();
        response.getWriter().close();
    }
}

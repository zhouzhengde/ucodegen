package com.moi.mypt.redis;

import java.io.Serializable;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.session.Session;

public class SerializationUtils {

    public static String serialize(Session session) {
        return Base64.encodeToString(org.apache.commons.lang3.SerializationUtils.serialize((Serializable) session));
    }

    public static Session deserialize(String sessionStr) {
        return org.apache.commons.lang3.SerializationUtils.deserialize(Base64.decode(sessionStr));
    }

    public static String serializeCommon(Serializable object) {
        return Base64.encodeToString(org.apache.commons.lang3.SerializationUtils.serialize(object));
    }

    public static Object deserializeCommon(String sessionStr) {
        return org.apache.commons.lang3.SerializationUtils.deserialize(Base64.decode(sessionStr));
    }
}